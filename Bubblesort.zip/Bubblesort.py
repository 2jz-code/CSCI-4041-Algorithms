import random, timeit

def mystery1(vals):
    diff = 0
    maximum = vals[0]
    minimum = vals[0]
    for i in range(1, len(vals)):
        if vals[i] > maximum:
            maximum = vals[i]
        if vals[i] < minimum:
            minimum = vals[i]
        diff = maximum - minimum
    return diff


def mystery2(filename):
    time = {}
    with open(filename) as fp:
        text = fp.read()
        for ltr in text:
            if ltr in time:
                time[ltr] = time[ltr] + 1
            else:
                time[ltr] = 1
    return time
    


def mystery3(filename):
    storage = []
    with open(filename) as fp:
        for line in fp:
            items = line.split()
            name = items[0]
            time = int(items[1])
            storage.append([name, time])
        sorted = []
        for i in range(len(storage)):                                  
            for j in range(0, len(storage)-i-1):                       
                if storage[j][1] > storage[j+1][1]:                     
                    storage[j], storage[j+1] = storage[j+1], storage[j] 
        for i in range(len(storage)):                                   
            sorted.append(storage[i][0])                               
    return sorted

if __name__ == '__main__':
    lst = [random.randint(0, 9999999) for i in range(1000)]
    time1 = timeit.timeit('mystery1(lst)', globals=globals(), number = 10)
    out = mystery1(lst)
    print("mystery1(lst) output:", out)
    print("mystery1(lst) runtime:", time1, "seconds")
    print('\n------------------\n')
    time2 = timeit.timeit('mystery2("wizard.txt")', globals=globals(), number = 10)
    out = mystery2('wizard.txt')
    print("mystery2('wizard.txt') output:", out)
    print("mystery2('wizard.txt') runtime:", time2, "seconds")
    print('\n------------------\n')
    time3 = timeit.timeit('mystery3("screentime_ms.txt")', globals=globals(), number = 10)
    out = mystery3("screentime_ms.txt")
    print("mystery3('screentime_ms.txt') output:", out)
    print("mystery3('screentime_ms.txt') runtime:", time3, "seconds")


