# How to Compile and Run
- run co2_LS.py
# Required installations
- Python3
- Numpy
- Matplotlib
- Pandas
# Project Description
Parse through a .csv containing data
Create and display a least squares fit for the data