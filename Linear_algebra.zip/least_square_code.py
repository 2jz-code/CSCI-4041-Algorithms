import pandas as pd
import numpy as np
from matplotlib import pyplot as plt

# Define the data points
data = pd.read_csv('co2_data.csv')
x = data.iloc[:,0]
y = data.iloc[:,1]

# Plot the data points
plt.plot(x, y, 'o', label='Original Data: Atmospheric CO2 (PPM)', markersize = 5)

# Add a legends and show the plot
plt.legend()
plt.show()

# make a matrix A
A = np.vstack([x, np.ones(len(x))]).T
print(A, '\n')

# numpy function for linear least square
m, s = np.linalg.lstsq(A, y, rcond=None)[0]
print(m, s)

# plotting data
plt.plot(x, y, 'o', label='Original Data: Atmospheric CO2 (PPM)', markersize = 5)
plt.plot(x, m*x + s, 'r', label='LS fit')
plt.legend()
plt.show()

# Calculate the residuals
residuals = y - (m*x + s)

# Calculate the mean squared error (MSE)
MSE = np.mean(residuals**2)
print("Mean Squared Error:", MSE)