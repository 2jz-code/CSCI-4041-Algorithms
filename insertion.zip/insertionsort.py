import csv

def find_closest(filename):
    with open(filename, 'r') as file:
        csv_reader = csv.reader(file)
        csv_data = list(csv_reader)

        low_diff = float('inf')
        names_of_least_diff = []
        for i in range(1, len(csv_data)):
            for j in range(i+1, len(csv_data)):
                new_diff = abs(float(csv_data[i][1]) - float(csv_data[j][1]))
                if new_diff < low_diff:
                    low_diff = new_diff
                    names_of_least_diff = [csv_data[i][0], csv_data[j][0]]
    return names_of_least_diff
